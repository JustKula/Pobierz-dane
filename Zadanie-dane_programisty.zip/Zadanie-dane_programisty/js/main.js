function pobierzDane(){
      var xmlhttp = new XMLHttpRequest();
      
          xmlhttp.onreadystatechange = function() {
              if (xmlhttp.readyState == XMLHttpRequest.DONE) { 
                 if (xmlhttp.status == 200) {
    				 if(!document.getElementById("dane-programisty")){
    					var htmlDiv = document.createElement('div');
    					htmlDiv.setAttribute('id','dane-programisty');
    					document.body.appendChild(htmlDiv);
    				 }
    				document.getElementById("dane-programisty").innerHTML += xmlhttp.responseText;
                 }
              }
          };
      
        xmlhttp.open("GET", "https://akademia108.pl/kurs-front-end/ajax/1-pobierz-dane-programisty.php", true);
        xmlhttp.send();
    }



